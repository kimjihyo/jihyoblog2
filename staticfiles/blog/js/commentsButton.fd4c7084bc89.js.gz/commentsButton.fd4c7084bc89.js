$(document).ready(function () {
    $("#view-comment span").click(function () {
        $("#comment-section").toggle();
    });
});